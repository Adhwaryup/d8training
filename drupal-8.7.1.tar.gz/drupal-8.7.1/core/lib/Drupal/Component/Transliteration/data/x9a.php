<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'e', 'cheng', 'xing', 'ai', 'lu', 'zhui', 'zhou', 'she', 'pian', 'kun', 'tao', 'lai', 'zong', 'ke', 'qi', 'qi',
  0x10 => 'yan', 'fei', 'sao', 'yan', 'ge', 'yao', 'wu', 'pian', 'cong', 'pian', 'qian', 'fei', 'huang', 'qian', 'huo', 'yu',
  0x20 => 'ti', 'quan', 'xia', 'zong', 'kui', 'rou', 'si', 'gua', 'tuo', 'gui', 'sou', 'qian', 'cheng', 'zhi', 'liu', 'peng',
  0x30 => 'teng', 'xi', 'cao', 'du', 'yan', 'yuan', 'zou', 'sao', 'shan', 'li', 'zhi', 'shuang', 'lu', 'xi', 'luo', 'zhang',
  0x40 => 'mo', 'ao', 'can', 'biao', 'cong', 'qu', 'bi', 'zhi', 'yu', 'xu', 'hua', 'bo', 'su', 'xiao', 'lin', 'zhan',
  0x50 => 'dun', 'liu', 'tuo', 'ceng', 'dian', 'jiao', 'tie', 'yan', 'luo', 'zhan', 'jing', 'yi', 'ye', 'tuo', 'pin', 'zhou',
  0x60 => 'yan', 'long', 'lu', 'teng', 'xiang', 'ji', 'shuang', 'ju', 'xi', 'huan', 'li', 'biao', 'ma', 'yu', 'tuo', 'xun',
  0x70 => 'chi', 'qu', 'ri', 'bo', 'lu', 'zang', 'shi', 'si', 'fu', 'ju', 'zou', 'zhu', 'tuo', 'nu', 'jia', 'yi',
  0x80 => 'dai', 'xiao', 'ma', 'yin', 'jiao', 'hua', 'luo', 'hai', 'pian', 'biao', 'li', 'cheng', 'yan', 'xing', 'qin', 'jun',
  0x90 => 'qi', 'qi', 'ke', 'zhui', 'zong', 'su', 'can', 'pian', 'zhi', 'kui', 'sao', 'wu', 'ao', 'liu', 'qian', 'shan',
  0xA0 => 'biao', 'luo', 'cong', 'chan', 'zhou', 'ji', 'shuang', 'xiang', 'gu', 'wei', 'wei', 'wei', 'yu', 'gan', 'yi', 'ang',
  0xB0 => 'tou', 'jie', 'bao', 'bei', 'ci', 'ti', 'di', 'ku', 'hai', 'qiao', 'hou', 'kua', 'ge', 'tui', 'geng', 'pian',
  0xC0 => 'bi', 'ke', 'qia', 'yu', 'sui', 'lou', 'bo', 'xiao', 'bang', 'bo', 'ci', 'kuan', 'bin', 'mo', 'liao', 'lou',
  0xD0 => 'xiao', 'du', 'zang', 'sui', 'ti', 'bin', 'kuan', 'lu', 'gao', 'gao', 'qiao', 'kao', 'qiao', 'lao', 'sao', 'biao',
  0xE0 => 'kun', 'kun', 'di', 'fang', 'xiu', 'ran', 'mao', 'dan', 'kun', 'bin', 'fa', 'tiao', 'pi', 'zi', 'fa', 'ran',
  0xF0 => 'ti', 'bao', 'bi', 'mao', 'fu', 'er', 'rong', 'qu', 'gong', 'xiu', 'kuo', 'ji', 'peng', 'zhua', 'shao', 'suo',
];
